def reverseWords(s):
    words = s.split()
    for i in range(len(words)):
        words[i] = words[i][::-1]
    result = ' '.join(words)
    return result
s = "Let's take LeetCode contest"
print(reverseWords(s))
