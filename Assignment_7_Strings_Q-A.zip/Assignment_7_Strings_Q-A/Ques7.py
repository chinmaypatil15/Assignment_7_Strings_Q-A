def process_string(s):
    stack = []
    for ch in s:
        if ch != '#':
            stack.append(ch)
        elif stack:
            stack.pop()
    return ''.join(stack)

def backspaceCompare(s, t):
    return process_string(s) == process_string(t)
s = "ab#c"
t = "ad#c"
print(backspaceCompare(s, t))
